from os import supports_effective_ids
import pygame
import random
import math

from pygame.sprite import spritecollide
from dna import DNA

class Phage(pygame.sprite.Sprite):
    def __init__(self, pos, WIDTH, HEIGHT, speed = 3):
        super().__init__()
        self.image = pygame.transform.scale(pygame.image.load('./Assets/phage - Copy.png'),\
            (61, 112)).convert_alpha()
        self.rect = self.image.get_rect(midtop = pos)
        self.height = HEIGHT
        self.width = WIDTH
        self.speed = speed
        self.direction = 'right'
        self.DNA_speed_min = 1
        self.DNA_speed_max = 5

        self.dna_molecules = pygame.sprite.Group()

    def shoot_dna(self):
        self.dna_molecules.add(DNA(self.rect.midbottom, self.height, self.DNA_speed_min, self.DNA_speed_max))

    def increase_speed(self):
        if self.DNA_speed_max <= 9:
            self.DNA_speed_min += 1
            self.DNA_speed_max += 1

    def reset(self):
        for dna in self.dna_molecules:
            dna.kill()
        self.DNA_speed_min = 1
        self.DNA_speed_max = 5

    def update(self):
        self.dna_molecules.update()        
        if self.direction == 'right' and self.rect.right <= 0.9 * self.width:
            self.rect.x += self.speed
            if self.rect.right >= 0.9 * self.width:
                self.direction = 'left'
        elif self.direction == 'left' and self.rect.left >= 0.1 * self.width:
            self.rect.x -= self.speed
            if self.rect.left <= 0.1 * self.width:
                self.direction = 'right'
