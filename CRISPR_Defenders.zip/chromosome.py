import pygame

class Chromosome(pygame.sprite.Sprite):
    def __init__(self, pos, WIDTH, OFFSET):
        super().__init__()
        self.width = WIDTH
        self.offset = OFFSET
        self.image = pygame.transform.scale(\
            pygame.image.load('./Assets/spaghetti - Copy.png'), (self.width - 40, self.offset))\
                .convert_alpha()
        self.rect = self.image.get_rect(midtop = pos)


    def update(self):
        pass