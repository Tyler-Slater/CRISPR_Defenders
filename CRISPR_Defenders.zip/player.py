import pygame
from crispr import CRISPR_Complex

class Player(pygame.sprite.Sprite):
    def __init__(self, pos, width, speed):
        super().__init__()
        self.image = pygame.transform.scale(pygame.image.load('./Assets/blob - Copy.png'),\
             (76, 84)).convert_alpha()
        self.rect = self.image.get_rect(midbottom = pos)
        self.speed = speed
        self.max_x = width - 5
        self.min_x = 5
        self.ready = True
        self.CRISPR_time = 0
        self.CRISPR_cooldown = 400

        self.lasers = pygame.sprite.Group()

    def get_input(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_RIGHT]:
            if self.rect.right < self.max_x:
                self.rect.x += self.speed
        elif keys[pygame.K_LEFT]:
            if self.rect.left > self.min_x:
                self.rect.x -= self.speed

        if keys[pygame.K_SPACE] and self.ready:
            self.shoot_laser()
            self.ready = False
            self.CRISPR_time = pygame.time.get_ticks()
        if keys[pygame.K_UP] and self.ready:
            self.shoot_laser()
            self.ready = False
            self.CRISPR_time = pygame.time.get_ticks()
    
    def shoot_laser(self):
        self.lasers.add(CRISPR_Complex(self.rect.center, self.rect.bottom))

    def recharge(self):
        if not self.ready:
            current_time = pygame.time.get_ticks()
            if current_time - self.CRISPR_time >= self.CRISPR_cooldown:
                self.ready = True

    def update(self):
        self.get_input()
        self.recharge()
        self.lasers.update()