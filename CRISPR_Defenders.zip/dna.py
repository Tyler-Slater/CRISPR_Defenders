import pygame
import random

class DNA(pygame.sprite.Sprite):
    def __init__(self, pos, HEIGHT, speed_min, speed_max):
        super().__init__()
        self.image = pygame.transform.scale(pygame.image.load('./Assets/dna - Copy.png'),\
             (34, 147)).convert_alpha()
        self.rect = self.image.get_rect(center = pos)
        self.current_time = pygame.time.get_ticks()
        self.speed_max = speed_max
        self.speed_min = speed_min
        self.speed = random.randint(self.speed_min, self.speed_max)
        self.height = HEIGHT

    def destroy(self):
        if self.rect.y <= -50 or self.rect.y >= self.height:
            self.kill()

    def update(self):
        self.rect.y += self.speed
        self.destroy()